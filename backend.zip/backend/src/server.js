require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const fsp = require('fs/promises');
const path = require('path');
const app = require('./app');
const pool = require('./services/db');

async function startup() {
  const DATA_DIR = process.env.DATA_DIR;
  const TEMP_DIR = process.env.TEMP_DIR;

  if (!DATA_DIR || !TEMP_DIR) {
    console.error('[STARTUP] DATA_DIR and TEMP_DIR must be set in .env');
    process.exit(1);
  }

  try {
    await fsp.mkdir(DATA_DIR, { recursive: true });
    console.log(`[STARTUP] DATA_DIR ready: ${DATA_DIR}`);
  } catch (err) {
    console.error('[STARTUP] Failed to create DATA_DIR:', err);
    process.exit(1);
  }

  try {
    await fsp.mkdir(TEMP_DIR, { recursive: true });
    console.log(`[STARTUP] TEMP_DIR ready: ${TEMP_DIR}`);
  } catch (err) {
    console.error('[STARTUP] Failed to create TEMP_DIR:', err);
    process.exit(1);
  }

  try {
    await fsp.mkdir(path.join(DATA_DIR, 'MISCELLANEOUS'), { recursive: true });
    console.log(`[STARTUP] MISCELLANEOUS dir ready`);
  } catch (err) {
    console.error('[STARTUP] Failed to create MISCELLANEOUS dir:', err);
    process.exit(1);
  }

  try {
    const conn = await pool.getConnection();
    conn.release();
    console.log('[STARTUP] DB connection OK');
  } catch (err) {
    console.error('[STARTUP] DB connection failed:', err);
    process.exit(1);
  }

  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => {
    console.log(`[STARTUP] MACHA API listening on port ${PORT}`);
  });
}

startup();
