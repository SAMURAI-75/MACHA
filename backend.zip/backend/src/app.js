const express = require('express');
const setupRouter = require('./routes/setup');
const subjectsRouter = require('./routes/subjects');
const resourcesRouter = require('./routes/resources');
const miscellaneousRouter = require('./routes/miscellaneous');
const deadlinesRouter = require('./routes/deadlines');
const remindersRouter = require('./routes/reminders');
const storageRouter = require('./routes/storage');
const errorHandler = require('./middleware/errorHandler');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/api/v1/setup', setupRouter);
app.use('/api/v1/subjects', subjectsRouter);
app.use('/api/v1/resources', resourcesRouter);
app.use('/api/v1/miscellaneous', miscellaneousRouter);
app.use('/api/v1/deadlines', deadlinesRouter);
app.use('/api/v1/reminders', remindersRouter);
app.use('/api/v1/storage', storageRouter);

// errorHandler MUST be last
app.use(errorHandler);

module.exports = app;
