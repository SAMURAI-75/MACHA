const express = require('express');
const path = require('path');
const checkDiskSpace = require('check-disk-space').default;

const router = express.Router();

router.get('/status', async (req, res, next) => {
  try {
    const diskInfo = await checkDiskSpace(path.resolve(process.env.DATA_DIR));
    const available_gb = Math.round((diskInfo.free / (1024 * 1024 * 1024)) * 100) / 100;

    let status;
    if (available_gb < 3) {
      status = 'critical';
    } else if (available_gb < 5) {
      status = 'warning';
    } else {
      status = 'ok';
    }

    return res.status(200).json({ available_gb, status });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
