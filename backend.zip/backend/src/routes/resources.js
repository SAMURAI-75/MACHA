const express = require('express');
const fs = require('fs');
const pool = require('../services/db');
const upload = require('../middleware/upload');
const {
  deriveResourcePath,
  assertWithinDataDir,
  moveTempToFinal,
  deleteTempFile,
  deleteStoredFile,
  getContentType,
} = require('../services/fileSystem');

const router = express.Router();

const VALID_CATEGORIES = ['material', 'questions', 'info', 'miscellaneous'];
const VALID_FILE_TYPES = ['file', 'image', 'text', 'link'];

// POST /resources
router.post('/', upload.single('file'), async (req, res, next) => {
  const tempPath = req.file ? req.file.path : null;
  try {
    const { semester, subject_name, category, title, resource_type, file_type, content } = req.body;

    if (!semester || !subject_name || !category || !title || !resource_type || !file_type) {
      deleteTempFile(tempPath);
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'semester, subject_name, category, title, resource_type, file_type are required.' },
      });
    }
    if (!VALID_CATEGORIES.includes(category)) {
      deleteTempFile(tempPath);
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: `category must be one of: ${VALID_CATEGORIES.join(', ')}.` },
      });
    }
    if (!VALID_FILE_TYPES.includes(file_type)) {
      deleteTempFile(tempPath);
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: `file_type must be one of: ${VALID_FILE_TYPES.join(', ')}.` },
      });
    }
    if ((file_type === 'file' || file_type === 'image') && !req.file) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'file is required for file_type file or image.' },
      });
    }
    if ((file_type === 'text' || file_type === 'link') && !content) {
      deleteTempFile(tempPath);
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'content is required for file_type text or link.' },
      });
    }

    const [subjects] = await pool.execute(
      'SELECT id FROM subjects WHERE name = ? AND semester = ?',
      [subject_name, semester]
    );
    if (subjects.length === 0) {
      deleteTempFile(tempPath);
      return res.status(404).json({
        error: { code: 'SUBJECT_NOT_FOUND', message: `Subject "${subject_name}" not found for ${semester}.` },
      });
    }
    const subject_id = subjects[0].id;

    const [existing] = await pool.execute(
      'SELECT id FROM resources WHERE subject_id = ? AND category = ? AND title = ?',
      [subject_id, category, title]
    );
    if (existing.length > 0) {
      deleteTempFile(tempPath);
      return res.status(409).json({
        error: { code: 'TITLE_EXISTS', message: `Title "${title}" already exists in ${category}.` },
      });
    }

    if (file_type === 'file' || file_type === 'image') {
      const finalPath = deriveResourcePath(semester, subject_name, category, title);

      let insertId;
      try {
        const [result] = await pool.execute(
          'INSERT INTO resources (subject_id, title, resource_type, category, file_path, file_type) VALUES (?, ?, ?, ?, ?, ?)',
          [subject_id, title, resource_type, category, finalPath, file_type]
        );
        insertId = result.insertId;
      } catch (dbErr) {
        deleteTempFile(tempPath);
        if (dbErr.code === 'ER_DUP_ENTRY') {
          return res.status(409).json({ error: { code: 'TITLE_EXISTS', message: 'Title already exists.' } });
        }
        throw dbErr;
      }

      try {
        await moveTempToFinal(tempPath, finalPath);
      } catch (moveErr) {
        await pool.execute('DELETE FROM resources WHERE id = ?', [insertId]);
        deleteTempFile(tempPath);
        throw moveErr;
      }

      return res.status(201).json({ resource_id: insertId, subject_id });
    } else {
      let insertId;
      try {
        const [result] = await pool.execute(
          'INSERT INTO resources (subject_id, title, resource_type, category, content, file_type) VALUES (?, ?, ?, ?, ?, ?)',
          [subject_id, title, resource_type, category, content, file_type]
        );
        insertId = result.insertId;
      } catch (dbErr) {
        if (dbErr.code === 'ER_DUP_ENTRY') {
          return res.status(409).json({ error: { code: 'TITLE_EXISTS', message: 'Title already exists.' } });
        }
        throw dbErr;
      }
      return res.status(201).json({ resource_id: insertId, subject_id });
    }
  } catch (err) {
    deleteTempFile(tempPath);
    next(err);
  }
});

// GET /resources/:id
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      `SELECT r.id, r.subject_id, s.archived, r.title, r.resource_type, r.category,
              r.file_type, r.content, r.created_at
       FROM resources r
       JOIN subjects s ON s.id = r.subject_id
       WHERE r.id = ?`,
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Resource ${id} not found.` } });
    }

    const r = rows[0];
    return res.status(200).json({
      id: r.id,
      subject_id: r.subject_id,
      subject_archived: r.archived === 1 || r.archived === true,
      title: r.title,
      resource_type: r.resource_type,
      category: r.category,
      file_type: r.file_type,
      content: (r.file_type === 'file' || r.file_type === 'image') ? null : r.content,
      created_at: r.created_at,
    });
  } catch (err) {
    next(err);
  }
});

// GET /resources/:id/file
router.get('/:id/file', async (req, res, next) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      'SELECT title, file_type, file_path FROM resources WHERE id = ?',
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Resource ${id} not found.` } });
    }

    const r = rows[0];
    if (r.file_type === 'text' || r.file_type === 'link') {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'This resource has no binary file.' } });
    }

    assertWithinDataDir(r.file_path);
    res.setHeader('Content-Type', getContentType(r.file_type));
    res.setHeader('Content-Disposition', `attachment; filename="${r.title}"`);

    const stream = fs.createReadStream(r.file_path);
    stream.on('error', err => next(err));
    stream.pipe(res);
  } catch (err) {
    next(err);
  }
});

// PUT /resources/:id
router.put('/:id', upload.single('file'), async (req, res, next) => {
  const tempPath = req.file ? req.file.path : null;
  try {
    const { id } = req.params;
    const { title, content, file_type } = req.body;

    if (!title && !content && !file_type && !req.file) {
      deleteTempFile(tempPath);
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'At least one field (title, content, file_type, file) is required.' },
      });
    }

    const [rows] = await pool.execute(
      `SELECT r.*, s.semester, s.name AS subject_name
       FROM resources r JOIN subjects s ON s.id = r.subject_id WHERE r.id = ?`,
      [id]
    );
    if (rows.length === 0) {
      deleteTempFile(tempPath);
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Resource ${id} not found.` } });
    }

    const current = rows[0];
    const updates = [];
    const values = [];

    if (title) { updates.push('title = ?'); values.push(title); }
    if (content) { updates.push('content = ?'); values.push(content); }
    if (file_type) { updates.push('file_type = ?'); values.push(file_type); }

    let newPath = null;
    let oldPath = null;

    if (req.file) {
      const effectiveTitle = title || current.title;
      newPath = deriveResourcePath(current.semester, current.subject_name, current.category, effectiveTitle);
      oldPath = current.file_path || null;
      updates.push('file_path = ?');
      values.push(newPath);
    }

    // DB update first — spec requires this order
    values.push(id);
    await pool.execute(`UPDATE resources SET ${updates.join(', ')} WHERE id = ?`, values);

    // File move after successful DB update
    if (req.file && newPath) {
      try {
        await moveTempToFinal(tempPath, newPath);
      } catch (moveErr) {
        deleteTempFile(tempPath);
        throw moveErr;
      }

      if (oldPath && oldPath !== newPath) {
        try { await deleteStoredFile(oldPath); } catch { /* non-fatal */ }
      }
    }

    return res.status(200).json({ resource_id: parseInt(id, 10), updated: true });
  } catch (err) {
    deleteTempFile(tempPath);
    next(err);
  }
});

// DELETE /resources/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      'SELECT id, file_type, file_path FROM resources WHERE id = ?',
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Resource ${id} not found.` } });
    }

    const r = rows[0];

    if ((r.file_type === 'file' || r.file_type === 'image') && r.file_path) {
      try {
        assertWithinDataDir(r.file_path);
        await deleteStoredFile(r.file_path);
      } catch {
        return res.status(500).json({
          error: { code: 'DISK_DELETE_FAILED', message: 'Could not delete file from disk.' },
        });
      }
    }

    try {
      await pool.execute('DELETE FROM resources WHERE id = ?', [id]);
    } catch {
      return res.status(500).json({
        error: { code: 'DB_DELETE_FAILED', message: 'File deleted from disk but DB row could not be removed.' },
      });
    }

    return res.status(200).json({ resource_id: parseInt(id, 10), deleted: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
