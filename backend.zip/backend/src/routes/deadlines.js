const express = require('express');
const pool = require('../services/db');

const router = express.Router();

function toMySQLDatetime(ms) {
  return new Date(ms).toISOString().slice(0, 19).replace('T', ' ');
}

// Date.parse() treats timezone-naive strings as LOCAL time, not UTC.
// The agent sends bare ISO strings (no Z/offset) per the API spec.
// This function appends Z so they are always parsed as UTC.
function parseUTC(str) {
  if (!str) return NaN;
  const s = str.trim();
  return /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(s)
    ? Date.parse(s + 'Z')
    : Date.parse(s);
}

// POST /deadlines
router.post('/', async (req, res, next) => {
  try {
    const { title, description, due_date, subject_id, misc_id } = req.body;

    if (!title) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'title is required.' } });
    }
    if (!due_date) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'due_date is required.' } });
    }

    const hasBoth = subject_id != null && misc_id != null;
    const hasNeither = subject_id == null && misc_id == null;
    if (hasBoth || hasNeither) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'Exactly one of subject_id or misc_id is required.' },
      });
    }

    const dueDateMs = parseUTC(due_date);
    if (isNaN(dueDateMs)) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'due_date is not a valid datetime.' } });
    }
    if (dueDateMs <= Date.now()) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'due_date must be in the future.' } });
    }

    if (subject_id != null) {
      const [rows] = await pool.execute('SELECT id FROM subjects WHERE id = ?', [subject_id]);
      if (rows.length === 0) {
        return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Subject ${subject_id} not found.` } });
      }
    }
    if (misc_id != null) {
      const [rows] = await pool.execute('SELECT id FROM miscellaneous WHERE id = ?', [misc_id]);
      if (rows.length === 0) {
        return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Miscellaneous item ${misc_id} not found.` } });
      }
    }

    const dueDateStr = toMySQLDatetime(dueDateMs);
    const [result] = await pool.execute(
      'INSERT INTO deadlines (subject_id, misc_id, title, description, due_date) VALUES (?, ?, ?, ?, ?)',
      [subject_id || null, misc_id || null, title, description || null, dueDateStr]
    );
    const deadlineId = result.insertId;

    const reminderOffsets = [2 * 60 * 60 * 1000, 1 * 60 * 60 * 1000];
    const now = Date.now();
    const remindersCreated = [];

    for (const offset of reminderOffsets) {
      const reminderMs = dueDateMs - offset;
      if (reminderMs > now) {
        const reminderStr = toMySQLDatetime(reminderMs);
        await pool.execute(
          'INSERT INTO reminders (deadline_id, reminder_time) VALUES (?, ?)',
          [deadlineId, reminderStr]
        );
        // Return ISO 8601 with T separator (matches API spec and Agent Guide)
        remindersCreated.push(new Date(reminderMs).toISOString().slice(0, 19));
      }
    }

    return res.status(201).json({ deadline_id: deadlineId, reminders_created: remindersCreated });
  } catch (err) {
    next(err);
  }
});

// GET /deadlines
router.get('/', async (req, res, next) => {
  try {
    const { subject_id, misc_id, from, to, completed } = req.query;

    const conditions = [];
    const values = [];

    const showCompleted = completed === 'true';

    const fromMs = from ? parseUTC(from) : null;
    // Always pass the UTC cutoff as a parameter — never use NOW() directly in
    // SQL because MySQL's NOW() follows the server's local timezone, not UTC.
    const fromStr = (fromMs && !isNaN(fromMs))
      ? toMySQLDatetime(fromMs)
      : toMySQLDatetime(Date.now());

    // Only apply the from-filter when listing incomplete deadlines (the default).
    // Completed deadlines may have passed their due_date already, so we don't
    // filter by date when the caller explicitly requests completed items.
    if (!showCompleted) {
      conditions.push('due_date >= ?');
      values.push(fromStr);
    } else if (from) {
      // Explicit from param: honour it even for completed
      conditions.push('due_date >= ?');
      values.push(fromStr);
    }

    if (to) {
      const toMs = parseUTC(to);
      if (!isNaN(toMs)) {
        conditions.push('due_date <= ?');
        values.push(toMySQLDatetime(toMs));
      }
    }

    if (subject_id != null) { conditions.push('subject_id = ?'); values.push(subject_id); }
    if (misc_id != null) { conditions.push('misc_id = ?'); values.push(misc_id); }
    conditions.push('is_completed = ?');
    values.push(showCompleted ? 1 : 0);

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const [rows] = await pool.execute(
      `SELECT id, title, description, due_date, is_completed, subject_id, misc_id
       FROM deadlines ${where} ORDER BY due_date ASC`,
      values
    );

    return res.status(200).json({
      deadlines: rows.map(r => ({
        id: r.id,
        title: r.title,
        description: r.description,
        due_date: r.due_date,
        is_completed: r.is_completed === 1 || r.is_completed === true,
        subject_id: r.subject_id,
        misc_id: r.misc_id,
      })),
    });
  } catch (err) {
    next(err);
  }
});

// PATCH /deadlines/:id/complete — MUST be before PATCH /:id
router.patch('/:id/complete', async (req, res, next) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute('SELECT id FROM deadlines WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Deadline ${id} not found.` } });
    }

    await pool.execute('UPDATE deadlines SET is_completed = TRUE WHERE id = ?', [id]);
    return res.status(200).json({ deadline_id: parseInt(id, 10), is_completed: true });
  } catch (err) {
    next(err);
  }
});

// PATCH /deadlines/:id
router.patch('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { title, description, due_date } = req.body;

    if (!title && description === undefined && !due_date) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'At least one field (title, description, due_date) is required.' },
      });
    }

    const [rows] = await pool.execute('SELECT id FROM deadlines WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Deadline ${id} not found.` } });
    }

    const updates = [];
    const values = [];

    if (title) { updates.push('title = ?'); values.push(title); }
    if (description !== undefined) { updates.push('description = ?'); values.push(description); }

    let newDueDateMs = null;
    if (due_date) {
      newDueDateMs = parseUTC(due_date);
      if (isNaN(newDueDateMs)) {
        return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'due_date is not a valid datetime.' } });
      }
      updates.push('due_date = ?');
      values.push(toMySQLDatetime(newDueDateMs));
    }

    // UPDATE deadlines first — reminders depend on the committed due_date
    values.push(id);
    await pool.execute(`UPDATE deadlines SET ${updates.join(', ')} WHERE id = ?`, values);

    // Only after a successful UPDATE do we recreate reminders
    if (newDueDateMs !== null) {
      await pool.execute('DELETE FROM reminders WHERE deadline_id = ?', [id]);

      const now = Date.now();
      const reminderOffsets = [2 * 60 * 60 * 1000, 1 * 60 * 60 * 1000];
      for (const offset of reminderOffsets) {
        const reminderMs = newDueDateMs - offset;
        if (reminderMs > now) {
          await pool.execute(
            'INSERT INTO reminders (deadline_id, reminder_time) VALUES (?, ?)',
            [id, toMySQLDatetime(reminderMs)]
          );
        }
      }
    }

    return res.status(200).json({ deadline_id: parseInt(id, 10), updated: true });
  } catch (err) {
    next(err);
  }
});

// DELETE /deadlines/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute('SELECT id FROM deadlines WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Deadline ${id} not found.` } });
    }

    await pool.execute('DELETE FROM deadlines WHERE id = ?', [id]);
    return res.status(200).json({ deadline_id: parseInt(id, 10), deleted: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
