const express = require('express');
const pool = require('../services/db');
const { createSubjectFolders } = require('../services/fileSystem');

const router = express.Router();

// POST /subjects
router.post('/', async (req, res, next) => {
  try {
    const { semester, name } = req.body;
    if (!semester || !name) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'semester and name are required.' },
      });
    }

    let subjectId;
    try {
      const [result] = await pool.execute(
        'INSERT INTO subjects (name, semester) VALUES (?, ?)',
        [name.trim(), semester]
      );
      subjectId = result.insertId;
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({
          error: { code: 'SUBJECT_EXISTS', message: `Subject "${name}" already exists for ${semester}.` },
        });
      }
      throw err;
    }

    try {
      await createSubjectFolders(semester, name.trim());
    } catch (fsErr) {
      await pool.execute('DELETE FROM subjects WHERE id = ?', [subjectId]);
      throw fsErr;
    }

    return res.status(201).json({ subject_id: subjectId, name: name.trim(), semester });
  } catch (err) {
    next(err);
  }
});

// PATCH /subjects/archive — MUST be before /:id
router.patch('/archive', async (req, res, next) => {
  try {
    const { semester, archive } = req.body;
    if (!semester) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'semester is required.' },
      });
    }

    const shouldArchive = archive !== false;

    const [rows] = await pool.execute(
      'SELECT id, archived FROM subjects WHERE semester = ?',
      [semester]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        error: { code: 'NOT_FOUND', message: `No subjects found for semester "${semester}".` },
      });
    }

    const targetState = shouldArchive ? (1) : (0);
    if (rows.every(r => (r.archived === 1 || r.archived === true) === shouldArchive)) {
      const code = shouldArchive ? 'ALREADY_ARCHIVED' : 'ALREADY_UNARCHIVED';
      const msg = shouldArchive
        ? `All subjects for "${semester}" are already archived.`
        : `All subjects for "${semester}" are already unarchived.`;
      return res.status(400).json({ error: { code, message: msg } });
    }

    await pool.execute(
      `UPDATE subjects SET archived = ${shouldArchive ? 'TRUE' : 'FALSE'} WHERE semester = ?`,
      [semester]
    );

    return res.status(200).json({ semester, archived_count: rows.length });
  } catch (err) {
    next(err);
  }
});

// GET /subjects?semester=SEM_3
router.get('/', async (req, res, next) => {
  try {
    const { semester } = req.query;
    if (!semester) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'semester query param is required.' },
      });
    }

    const [rows] = await pool.execute(
      'SELECT id, name, archived FROM subjects WHERE semester = ?',
      [semester]
    );

    return res.status(200).json({
      subjects: rows.map(r => ({
        id: r.id,
        name: r.name,
        archived: r.archived === 1 || r.archived === true,
      })),
    });
  } catch (err) {
    next(err);
  }
});

// GET /subjects/:id/resource-types
router.get('/:id/resource-types', async (req, res, next) => {
  try {
    const { id } = req.params;

    const [subjects] = await pool.execute('SELECT id FROM subjects WHERE id = ?', [id]);
    if (subjects.length === 0) {
      return res.status(404).json({
        error: { code: 'SUBJECT_NOT_FOUND', message: `Subject ${id} not found.` },
      });
    }

    const [rows] = await pool.execute(
      'SELECT DISTINCT resource_type, category FROM resources WHERE subject_id = ?',
      [id]
    );

    return res.status(200).json({
      subject_id: parseInt(id, 10),
      resource_types: rows.map(r => ({ resource_type: r.resource_type, category: r.category })),
    });
  } catch (err) {
    next(err);
  }
});

// GET /subjects/:id/resources?category=material
router.get('/:id/resources', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { category } = req.query;

    if (!category) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'category query param is required.' },
      });
    }

    const [subjects] = await pool.execute('SELECT id FROM subjects WHERE id = ?', [id]);
    if (subjects.length === 0) {
      return res.status(404).json({
        error: { code: 'SUBJECT_NOT_FOUND', message: `Subject ${id} not found.` },
      });
    }

    const [rows] = await pool.execute(
      'SELECT id, title, file_type FROM resources WHERE subject_id = ? AND category = ?',
      [id, category]
    );

    return res.status(200).json({
      subject_id: parseInt(id, 10),
      category,
      resources: rows.map(r => ({ id: r.id, title: r.title, file_type: r.file_type })),
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
