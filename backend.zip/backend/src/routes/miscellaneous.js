const express = require('express');
const fs = require('fs');
const pool = require('../services/db');
const upload = require('../middleware/upload');
const {
  deriveMiscPath,
  assertWithinDataDir,
  ensureMiscCategoryFolder,
  moveTempToFinal,
  deleteTempFile,
  deleteStoredFile,
  getContentType,
} = require('../services/fileSystem');

const router = express.Router();

const VALID_FILE_TYPES = ['file', 'image', 'text', 'link'];

// GET /miscellaneous/categories — MUST be before GET /:id
router.get('/categories', async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      'SELECT DISTINCT category FROM miscellaneous ORDER BY category ASC'
    );
    return res.status(200).json({ categories: rows.map(r => r.category) });
  } catch (err) {
    next(err);
  }
});

// GET /miscellaneous?category=events — MUST be before GET /:id
router.get('/', async (req, res, next) => {
  try {
    const { category } = req.query;
    if (!category) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'category query param is required.' },
      });
    }

    const [rows] = await pool.execute(
      'SELECT id, title, file_type FROM miscellaneous WHERE category = ?',
      [category]
    );

    return res.status(200).json({ category, items: rows.map(r => ({ id: r.id, title: r.title, file_type: r.file_type })) });
  } catch (err) {
    next(err);
  }
});

// POST /miscellaneous
router.post('/', upload.single('file'), async (req, res, next) => {
  const tempPath = req.file ? req.file.path : null;
  try {
    const { title, category, file_type, content } = req.body;

    if (!title || !category || !file_type) {
      deleteTempFile(tempPath);
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'title, category, and file_type are required.' },
      });
    }
    if (!VALID_FILE_TYPES.includes(file_type)) {
      deleteTempFile(tempPath);
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: `file_type must be one of: ${VALID_FILE_TYPES.join(', ')}.` },
      });
    }
    if ((file_type === 'file' || file_type === 'image') && !req.file) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'file is required for file_type file or image.' },
      });
    }
    if ((file_type === 'text' || file_type === 'link') && !content) {
      deleteTempFile(tempPath);
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'content is required for file_type text or link.' },
      });
    }

    const [existing] = await pool.execute(
      'SELECT id FROM miscellaneous WHERE category = ? AND title = ?',
      [category, title]
    );
    if (existing.length > 0) {
      deleteTempFile(tempPath);
      return res.status(409).json({
        error: { code: 'TITLE_EXISTS', message: `Title "${title}" already exists in category "${category}".` },
      });
    }

    const categoryCreated = await ensureMiscCategoryFolder(category);

    if (file_type === 'file' || file_type === 'image') {
      const finalPath = deriveMiscPath(category, title);

      let insertId;
      try {
        const [result] = await pool.execute(
          'INSERT INTO miscellaneous (title, category, file_path, file_type) VALUES (?, ?, ?, ?)',
          [title, category, finalPath, file_type]
        );
        insertId = result.insertId;
      } catch (dbErr) {
        deleteTempFile(tempPath);
        if (dbErr.code === 'ER_DUP_ENTRY') {
          return res.status(409).json({ error: { code: 'TITLE_EXISTS', message: 'Title already exists.' } });
        }
        throw dbErr;
      }

      try {
        await moveTempToFinal(tempPath, finalPath);
      } catch (moveErr) {
        await pool.execute('DELETE FROM miscellaneous WHERE id = ?', [insertId]);
        deleteTempFile(tempPath);
        throw moveErr;
      }

      return res.status(201).json({ misc_id: insertId, category_created: categoryCreated });
    } else {
      let insertId;
      try {
        const [result] = await pool.execute(
          'INSERT INTO miscellaneous (title, category, content, file_type) VALUES (?, ?, ?, ?)',
          [title, category, content, file_type]
        );
        insertId = result.insertId;
      } catch (dbErr) {
        if (dbErr.code === 'ER_DUP_ENTRY') {
          return res.status(409).json({ error: { code: 'TITLE_EXISTS', message: 'Title already exists.' } });
        }
        throw dbErr;
      }
      return res.status(201).json({ misc_id: insertId, category_created: categoryCreated });
    }
  } catch (err) {
    deleteTempFile(tempPath);
    next(err);
  }
});

// GET /miscellaneous/:id
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      'SELECT id, title, category, file_type, content, created_at FROM miscellaneous WHERE id = ?',
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Miscellaneous item ${id} not found.` } });
    }

    const r = rows[0];
    return res.status(200).json({
      id: r.id,
      title: r.title,
      category: r.category,
      file_type: r.file_type,
      content: (r.file_type === 'file' || r.file_type === 'image') ? null : r.content,
      created_at: r.created_at,
    });
  } catch (err) {
    next(err);
  }
});

// GET /miscellaneous/:id/file
router.get('/:id/file', async (req, res, next) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      'SELECT title, file_type, file_path FROM miscellaneous WHERE id = ?',
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Miscellaneous item ${id} not found.` } });
    }

    const r = rows[0];
    if (r.file_type === 'text' || r.file_type === 'link') {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'This item has no binary file.' } });
    }

    assertWithinDataDir(r.file_path);
    res.setHeader('Content-Type', getContentType(r.file_type));
    res.setHeader('Content-Disposition', `attachment; filename="${r.title}"`);

    const stream = fs.createReadStream(r.file_path);
    stream.on('error', err => next(err));
    stream.pipe(res);
  } catch (err) {
    next(err);
  }
});

// PUT /miscellaneous/:id
router.put('/:id', upload.single('file'), async (req, res, next) => {
  const tempPath = req.file ? req.file.path : null;
  try {
    const { id } = req.params;
    const { title, content, file_type } = req.body;

    if (!title && !content && !file_type && !req.file) {
      deleteTempFile(tempPath);
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'At least one field (title, content, file_type, file) is required.' },
      });
    }

    const [rows] = await pool.execute(
      'SELECT * FROM miscellaneous WHERE id = ?',
      [id]
    );
    if (rows.length === 0) {
      deleteTempFile(tempPath);
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Miscellaneous item ${id} not found.` } });
    }

    const current = rows[0];
    const updates = [];
    const values = [];

    if (title) { updates.push('title = ?'); values.push(title); }
    if (content) { updates.push('content = ?'); values.push(content); }
    if (file_type) { updates.push('file_type = ?'); values.push(file_type); }

    let newPath = null;
    let oldPath = null;

    if (req.file) {
      const effectiveTitle = title || current.title;
      newPath = deriveMiscPath(current.category, effectiveTitle);
      oldPath = current.file_path || null;
      updates.push('file_path = ?');
      values.push(newPath);
    }

    // DB update first — spec requires this order
    values.push(id);
    await pool.execute(`UPDATE miscellaneous SET ${updates.join(', ')} WHERE id = ?`, values);

    // File move after successful DB update
    if (req.file && newPath) {
      try {
        await moveTempToFinal(tempPath, newPath);
      } catch (moveErr) {
        deleteTempFile(tempPath);
        throw moveErr;
      }

      if (oldPath && oldPath !== newPath) {
        try { await deleteStoredFile(oldPath); } catch { /* non-fatal */ }
      }
    }

    return res.status(200).json({ misc_id: parseInt(id, 10), updated: true });
  } catch (err) {
    deleteTempFile(tempPath);
    next(err);
  }
});

// DELETE /miscellaneous/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      'SELECT id, file_type, file_path FROM miscellaneous WHERE id = ?',
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Miscellaneous item ${id} not found.` } });
    }

    const r = rows[0];

    if ((r.file_type === 'file' || r.file_type === 'image') && r.file_path) {
      try {
        assertWithinDataDir(r.file_path);
        await deleteStoredFile(r.file_path);
      } catch {
        return res.status(500).json({
          error: { code: 'DISK_DELETE_FAILED', message: 'Could not delete file from disk.' },
        });
      }
    }

    try {
      await pool.execute('DELETE FROM miscellaneous WHERE id = ?', [id]);
    } catch {
      return res.status(500).json({
        error: { code: 'DB_DELETE_FAILED', message: 'File deleted from disk but DB row could not be removed.' },
      });
    }

    return res.status(200).json({ misc_id: parseInt(id, 10), deleted: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
