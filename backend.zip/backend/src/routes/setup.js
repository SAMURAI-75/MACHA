const express = require('express');
const path = require('path');
const fsp = require('fs/promises');
const pool = require('../services/db');
const { createSubjectFolders, assertWithinDataDir } = require('../services/fileSystem');

const router = express.Router();

router.post('/semester', async (req, res, next) => {
  try {
    const { semester, subjects } = req.body;

    if (!semester || !Array.isArray(subjects) || subjects.length === 0) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'semester and subjects[] are required.' },
      });
    }

    const semesterDir = path.resolve(process.env.DATA_DIR, semester);
    assertWithinDataDir(semesterDir);
    await fsp.mkdir(semesterDir, { recursive: true });

    const created = [];
    const skipped = [];

    for (const name of subjects) {
      if (!name || typeof name !== 'string') {
        skipped.push(name);
        continue;
      }

      let subjectId;
      try {
        const [result] = await pool.execute(
          'INSERT INTO subjects (name, semester) VALUES (?, ?)',
          [name.trim(), semester]
        );
        subjectId = result.insertId;
      } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
          skipped.push(name.trim());
          continue;
        }
        throw err;
      }

      try {
        await createSubjectFolders(semester, name.trim());
        created.push(name.trim());
      } catch (fsErr) {
        await pool.execute('DELETE FROM subjects WHERE id = ?', [subjectId]);
        throw fsErr;
      }
    }

    return res.status(200).json({ semester, created, skipped });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
