const express = require('express');
const pool = require('../services/db');

const router = express.Router();

function toMySQLDatetime(ms) {
  return new Date(ms).toISOString().slice(0, 19).replace('T', ' ');
}

function parseUTC(str) {
  if (!str) return NaN;
  const s = str.trim();
  return /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(s)
    ? Date.parse(s + 'Z')
    : Date.parse(s);
}

// GET /reminders/due — MUST be before DELETE /:id
router.get('/due', async (req, res, next) => {
  try {
    const { as_of } = req.query;

    const cutoffMs = as_of ? parseUTC(as_of) : NaN;
    // Always pass the UTC cutoff as a parameter — MySQL NOW() follows the
    // server's local timezone, not UTC, so we compute it in Node.js instead.
    const cutoffStr = (!isNaN(cutoffMs))
      ? toMySQLDatetime(cutoffMs)
      : toMySQLDatetime(Date.now());

    const query = `
      SELECT r.id AS reminder_id, r.deadline_id, r.reminder_time,
             d.title AS deadline_title, d.due_date
      FROM reminders r
      JOIN deadlines d ON d.id = r.deadline_id
      WHERE r.reminder_time <= ?
        AND d.is_completed = FALSE
      ORDER BY r.reminder_time ASC
    `;
    const params = [cutoffStr];
    const [rows] = await pool.execute(query, params);

    return res.status(200).json({
      reminders: rows.map(r => ({
        reminder_id: r.reminder_id,
        deadline_id: r.deadline_id,
        deadline_title: r.deadline_title,
        due_date: r.due_date,
        reminder_time: r.reminder_time,
      })),
    });
  } catch (err) {
    next(err);
  }
});

// POST /reminders
router.post('/', async (req, res, next) => {
  try {
    const { deadline_id, reminder_time } = req.body;

    if (!deadline_id || !reminder_time) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'deadline_id and reminder_time are required.' },
      });
    }

    const [deadlines] = await pool.execute(
      'SELECT id, due_date FROM deadlines WHERE id = ?',
      [deadline_id]
    );
    if (deadlines.length === 0) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Deadline ${deadline_id} not found.` } });
    }

    const dueDateMs = new Date(deadlines[0].due_date).getTime();
    const reminderMs = parseUTC(reminder_time);

    if (isNaN(reminderMs)) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'reminder_time is not a valid datetime.' } });
    }
    if (reminderMs > dueDateMs) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'reminder_time must not be after the deadline due_date.' },
      });
    }

    const reminderStr = toMySQLDatetime(reminderMs);
    const [result] = await pool.execute(
      'INSERT INTO reminders (deadline_id, reminder_time) VALUES (?, ?)',
      [deadline_id, reminderStr]
    );

    return res.status(201).json({ reminder_id: result.insertId });
  } catch (err) {
    next(err);
  }
});

// DELETE /reminders/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute('SELECT id FROM reminders WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: `Reminder ${id} not found.` } });
    }

    await pool.execute('DELETE FROM reminders WHERE id = ?', [id]);
    return res.status(200).json({ reminder_id: parseInt(id, 10), deleted: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
