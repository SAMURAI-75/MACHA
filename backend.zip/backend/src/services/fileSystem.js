const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

const CONTENT_TYPES = {
  file: 'application/octet-stream',
  image: 'image/jpeg',
};

function getDataDir() {
  return path.resolve(process.env.DATA_DIR);
}

function assertWithinDataDir(resolvedPath) {
  const dataDir = getDataDir();
  if (!resolvedPath.startsWith(dataDir + path.sep) && resolvedPath !== dataDir) {
    throw new Error(`Path traversal detected: ${resolvedPath}`);
  }
}

function deriveResourcePath(semester, subjectName, category, title) {
  const resolved = path.resolve(getDataDir(), semester, subjectName, category, title);
  assertWithinDataDir(resolved);
  return resolved;
}

function deriveMiscPath(category, title) {
  const resolved = path.resolve(getDataDir(), 'MISCELLANEOUS', category, title);
  assertWithinDataDir(resolved);
  return resolved;
}

async function createSubjectFolders(semester, subjectName) {
  const subjectBase = path.resolve(getDataDir(), semester, subjectName);
  assertWithinDataDir(subjectBase);
  const subcategories = ['material', 'questions', 'info', 'miscellaneous'];
  await fsp.mkdir(subjectBase, { recursive: true });
  for (const sub of subcategories) {
    await fsp.mkdir(path.join(subjectBase, sub), { recursive: true });
  }
}

async function ensureMiscCategoryFolder(category) {
  const categoryPath = path.resolve(getDataDir(), 'MISCELLANEOUS', category);
  assertWithinDataDir(categoryPath);
  try {
    await fsp.access(categoryPath);
    return false;
  } catch {
    await fsp.mkdir(categoryPath, { recursive: true });
    return true;
  }
}

async function moveTempToFinal(tempPath, finalPath) {
  await fsp.mkdir(path.dirname(finalPath), { recursive: true });
  await fsp.rename(tempPath, finalPath);
}

function deleteTempFile(tempPath) {
  if (!tempPath) return;
  try {
    fs.unlinkSync(tempPath);
  } catch {
    // silent — temp cleanup is best-effort
  }
}

async function deleteStoredFile(filePath) {
  await fsp.unlink(filePath);
}

function getContentType(fileType) {
  return CONTENT_TYPES[fileType] || 'application/octet-stream';
}

module.exports = {
  deriveResourcePath,
  deriveMiscPath,
  assertWithinDataDir,
  createSubjectFolders,
  ensureMiscCategoryFolder,
  moveTempToFinal,
  deleteTempFile,
  deleteStoredFile,
  getContentType,
};
