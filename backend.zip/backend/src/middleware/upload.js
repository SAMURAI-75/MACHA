const multer = require('multer');
const path = require('path');
const crypto = require('crypto');

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, process.env.TEMP_DIR);
  },
  filename: (_req, _file, cb) => {
    cb(null, crypto.randomBytes(16).toString('hex'));
  },
});

const uploadMiddleware = multer({ storage });

module.exports = uploadMiddleware;
