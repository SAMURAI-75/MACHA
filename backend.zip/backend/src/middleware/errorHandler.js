const { deleteTempFile } = require('../services/fileSystem');

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  console.error('[MACHA ERROR]', err);

  if (req.file && req.file.path) {
    deleteTempFile(req.file.path);
  }

  res.status(500).json({
    error: {
      code: 'INTERNAL_ERROR',
      message: 'An unexpected error occurred.',
    },
  });
}

module.exports = errorHandler;
