CREATE TABLE subjects (
  id       INT AUTO_INCREMENT PRIMARY KEY,
  name     VARCHAR(100) NOT NULL,
  semester VARCHAR(20)  NOT NULL,
  archived BOOLEAN      DEFAULT FALSE NOT NULL,
  UNIQUE (name, semester)
);

CREATE TABLE resources (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  subject_id    INT          NOT NULL,
  title         VARCHAR(200) NOT NULL,
  resource_type VARCHAR(50)  NOT NULL,
  category      VARCHAR(50)  NOT NULL,
  file_path     VARCHAR(500) DEFAULT NULL,
  content       TEXT         DEFAULT NULL,
  file_type     VARCHAR(20)  DEFAULT NULL,
  created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_resource_has_content
    CHECK (file_path IS NOT NULL OR content IS NOT NULL),
  CONSTRAINT chk_resource_file_type
    CHECK (file_type IN ('file', 'image', 'text', 'link')),
  CONSTRAINT uq_resource_title
    UNIQUE (subject_id, category, title),
  FOREIGN KEY (subject_id) REFERENCES subjects(id),
  INDEX idx_resources_subject (subject_id)
);

CREATE TABLE miscellaneous (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  title      VARCHAR(200) NOT NULL,
  category   VARCHAR(50)  NOT NULL,
  content    TEXT         DEFAULT NULL,
  file_path  VARCHAR(500) DEFAULT NULL,
  file_type  VARCHAR(20)  DEFAULT NULL,
  created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_misc_has_content
    CHECK (file_path IS NOT NULL OR content IS NOT NULL),
  CONSTRAINT chk_misc_file_type
    CHECK (file_type IN ('file', 'image', 'text', 'link')),
  INDEX idx_misc_category (category)
);

CREATE TABLE deadlines (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  subject_id   INT          DEFAULT NULL,
  misc_id      INT          DEFAULT NULL,
  title        VARCHAR(200) NOT NULL,
  description  TEXT         DEFAULT NULL,
  due_date     DATETIME     NOT NULL,
  is_completed BOOLEAN      DEFAULT FALSE NOT NULL,
  created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_deadline_one_owner
    CHECK (
      (subject_id IS NOT NULL AND misc_id IS NULL) OR
      (subject_id IS NULL     AND misc_id IS NOT NULL)
    ),
  FOREIGN KEY (subject_id) REFERENCES subjects(id),
  FOREIGN KEY (misc_id)    REFERENCES miscellaneous(id),
  INDEX idx_deadlines_subject (subject_id),
  INDEX idx_deadlines_misc    (misc_id),
  INDEX idx_deadlines_due     (due_date)
);

CREATE TABLE reminders (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  deadline_id   INT       NOT NULL,
  reminder_time DATETIME  NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (deadline_id) REFERENCES deadlines(id) ON DELETE CASCADE,
  INDEX idx_reminders_time     (reminder_time),
  INDEX idx_reminders_deadline (deadline_id)
);
